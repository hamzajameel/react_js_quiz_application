export default(state = [],action ) => {
    switch (action.type){
        case 'FETCH_SELECTED_DATA':
        return {
            ...state,
            questions : action.payload,
            startTime : (new Date()).getTime(),

        }
        default:
            return state;

    }
}