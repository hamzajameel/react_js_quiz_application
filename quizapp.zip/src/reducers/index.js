import {combineReducers} from 'redux'
import fetchCategoriesReducer from './fetchCategories'
import resultsReducer from './resultsReducer'
export default combineReducers({
    categories : fetchCategoriesReducer,
    results : resultsReducer
})