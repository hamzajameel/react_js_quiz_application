import React from 'react';
import './App.css';
import Cat from './components/getCatagory'

function App() {
  return (
    <div className="App">
      <Cat />
    </div>
  );
}

export default App;
