import opentdb from '../apis/opentdb'
import {AllHtmlEntities as entities} from 'html-entities'
export const fetchCategories = () => async dispatch => {
    const resposne = await opentdb.get('/api_category.php');
    dispatch ({type : 'FETCH_CATEGORY', payload : resposne.data.trivia_categories})
    
}

export const fetchSelectedData = id => async dispatch => {
    const resposne = await opentdb.get(`/api.php?amount=10&category=${id}`);
    const formatedQuestions = resposne.data.results.map(questions => {
        const options = questions.incorrect_answers;
        options.push(questions.correct_answer)
        return {
            options : options.map(option => entities.decode(option)),
            category : questions.category,
            type : questions.type,
            difficulty : questions.difficulty,
            correct_answer : questions.correct_answer,
            question: entities.decode(questions.question),

        }

    })
    dispatch ({type : 'FETCH_SELECTED_DATA', payload : formatedQuestions})
    
}