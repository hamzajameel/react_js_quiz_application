import React from 'react'
import { connect } from 'react-redux'
import { fetchSelectedData } from '../actions'
const correct_answers = []
class selectedData extends React.Component {
    constructor(props) {
        super(props)
        this.state = {
            count: 0,
            correct_answers: [],
            iscompleted: false

        }

    }

    componentDidMount() {
        this.props.fetchSelectedData(this.props.id)



    }
    onSubmit = () => {
        const { count } = this.state;
        console.log(count)
        this.setState({ iscompleted: true })
        return (
            <div>You final score is : {count}</div>
        )
        console.log(count)
    }
    onCompleted = () => {
        return (
            <div>Your final score is: {this.state.count} </div>
        )
    }
    onChangeFavorite = (event) => {
        const { count } = this.state
        if (correct_answers.includes(event.target.value) === true) {
            this.setState({ count: count + 1 })
            console.log('yes');
        }
        else {
            this.setState({ count: count })
            console.log('no');
        }

    }
    renderData = () => {
        if (this.props.results.questions) {
            return (
                this.props.results.questions.map((data, index) => {
                    correct_answers.push(data.correct_answer)

                    return (
                        <div key={index}>
                            <h3 key={index}>Q{index + 1}) {data.question}</h3>
                            {data.options.map(option => {
                                return (


                                    <label>
                                        <input
                                            type="checkbox" value={option}
                                            onChange={this.onChangeFavorite}
                                            defaultChecked={false} />
                                        {option}
                                    </label>
                                )
                            })}
                        </div>
                    )
                })

            )


        }



    }
    render() {

        if (this.state.iscompleted === false) {
            return (
                <div>
                    {this.renderData()}
                    <button onClick={this.onSubmit}>Submit </button>

                </div>
            )

        }
        else {
            return (
                <div>
                    <div>{this.onCompleted()}</div>
                    <button>Play Again!</button>
                    </div>

            )
        }


    }
}
const mapStateToProps = (state) => {
    return { results: state.results }
}
export default connect(mapStateToProps,
    { fetchSelectedData }
)(selectedData)