import React from 'react'
import { connect } from 'react-redux'
import { fetchCategories, fetchSelectedData } from '../actions'
import GameStart from './selectedCategory'

class fetchdata extends React.Component {
    constructor(props) {
        super(props)
    this.state = {
        id : '',
        images : [
            {imgSrc : require(`../assets/imgs/general_knowledge.jpg`)},
            {imgSrc : require(`../assets/imgs/books.jpg`)},
            {imgSrc : require(`../assets/imgs/films.jpg`)},
            {imgSrc: require(`../assets/imgs/music.jpg`)},
            {imgSrc : require(`../assets/imgs/musical-theatre.jpg`)},
            {imgSrc : require(`../assets/imgs/television.jpg`)},
            {imgSrc : require(`../assets/imgs/video_games.jpg`)},
            {imgSrc : require(`../assets/imgs/board-game.jpg`)},
            {imgSrc : require(`../assets/imgs/nature_and_science.jpg`)},
            {imgSrc : require(`../assets/imgs/computers.jpg`)},
            {imgSrc : require(`../assets/imgs/mathematics.jpg`)},
            {imgSrc : require(`../assets/imgs/mathilogy.jpg`)},
            {imgSrc : require(`../assets/imgs/sports.jpg`)},
            {imgSrc : require(`../assets/imgs/geography.jpg`)},
            {imgSrc : require(`../assets/imgs/history.jpg`)},
            {imgSrc : require(`../assets/imgs/politics3.jpg`)},
            {imgSrc : require(`../assets/imgs/arts.jpg`)},
            {imgSrc : require(`../assets/imgs/celebrities.jpeg`)},
            {imgSrc : require(`../assets/imgs/animals.jpg`)},
            {imgSrc : require(`../assets/imgs/vehicles.jpg`)},
            {imgSrc : require(`../assets/imgs/comics.jpg`)},
            {imgSrc : require(`../assets/imgs/gedets.jpg`)},
            {imgSrc : require(`../assets/imgs/anime.jpg`)},
            {imgSrc : require(`../assets/imgs/animations.jpg`)},
        ]

    }

    }

    componentDidMount() {
        this.props.fetchCategories();
    }

    renderCategories = () => {
        return (
            this.props.categories.map(categories => {
                return (

                    <div key={categories.id}>
                        <button onClick={() => this.setState({id : categories.id})}>
                            {/* {this.state.images.map(img => {
                                return <img src={img} height='200px' width="200px" />

                            })} */}
                            {}
                            <h3>{categories.name}</h3>
                        </button>
                    </div>
                )
            })
        )
    }

    render() {
        
        if (this.state.id === "") {
            return (
                <div> {this.renderCategories()}</div>
                 
            )
        }
        else {
            return (
                <GameStart id = {this.state.id}/>
            )
        }


    }
}
const mapStateToProps = (state) => {
    return {
        categories: state.categories,
    }
}
export default connect(
    mapStateToProps,
    {
        fetchCategories,
        fetchSelectedData
    }
)(fetchdata)
